#include <iostream>
#include <thread>
#include <chrono>
#include <map>
#include <vector>
#include "json.hpp"
#include "httplib.h"

using json = nlohmann::json;

// Helper to convert JSON array keyed by "id" into map
std::unordered_map<std::string, json> to_map(const json& input) {
    std::unordered_map<std::string, json> output;
    if (input.is_array()) // verify input is a json array
    {
        for (const auto& item : input) 
        {
            if (item.find("id") != item.end()) // search for the id in the entry within the json array element
            {
                output[item["id"]] = item;
            }
        }
    }
    else if (input.is_object()) // check if input is a json object
    {
        output = input.get<std::unordered_map<std::string, json>>(); // retrieve it as a json object if it is object
    }
    return output;
}

// Fetch full details of a light by ID
json fetch_light_details(httplib::Client& client, const std::string& id)
{
    auto res = client.Get(("/lights/" + id).c_str()); // form endpoint to query to get light details
    if (res && res->status == 200) // if valid response
    {
        try
        {
            return json::parse(res->body); // parse the string response into a json
        }
        catch (...)
        {
            std::cerr << "Failed to parse JSON for light " << id << "\n"; // could not parse
        }
    }
    else
    {
        std::cerr << "Failed to fetch light " << id << " (status: " 
                  << (res ? std::to_string(res->status) : "no response") << ")\n"; // could not fetch light (server error most likely)
    }
    return nullptr;
}

// Polling function to check for changes and print diffs
void poll(httplib::Client &client, json &state)
{
    auto res = client.Get("/lights"); //Retrieve summary of all lights
    if (res && res->status == 200) // check for good response
    {
        try
        {
            json summary_lights = json::parse(res->body); // parse the string response to nlohmann json
            // create map of last poll and current poll respectively
            auto old_map = to_map(state);
            auto new_map = to_map(summary_lights);

            json new_state = json::object();
            bool any_change = false; // set flag for changes to false

            for (const auto& pair : new_map) { // iterate each key, value pair in the new map
                const auto& id = pair.first;
                const auto& summary_light = pair.second;
                json full_new = fetch_light_details(client, id); // get the granular details of each light by id
                if (full_new.is_null()) { // ensure full_new has a value
                    full_new = summary_light; // fallback
                }
                new_state[id] = full_new;

                if (old_map.find(id) == old_map.end()) // check if the new light can be found in the previous state map
                {
                    full_new["id"] = id;
                    std::cout << full_new.dump(4) << std::endl; // pretty print new light
                    any_change = true; // flag the change
                }
                else
                {
                    // Existing light — compare full objects
                    const json& old_full = old_map.at(id);
                    for (const auto& key_val_pair : full_new.items()) // iterate through each key value pair
                    {
                        const auto& key = key_val_pair.key();
                        const auto& val = key_val_pair.value();
                        if (!old_full.contains(key) || old_full.at(key) != val) // compare the old detail value of the light to the new detail value of the light
                        {
                            json diff_entry = { {"id", id}, {key, val} }; // log the id and the difference
                            std::cout << diff_entry.dump(4) << "\n";
                            any_change = true; // flag change
                        }
                    }
                }
            }

            // Detect removed lights
            for (const auto& pair : old_map) 
            {
                const auto& id = pair.first;
                const auto& val = pair.second;
                if (new_map.find(id) == new_map.end()) // search the new map for the id in the old map, if not found we know it has been removed
                {
                    std::cout << val["name"] << " (" << id << ") has been removed\n"; // Blue Lamp (3) has been removed
                    any_change = true; // flag change
                }
            }

            if (any_change) // if there are changes
            {
                state = new_state; // change the previous state to the new state
            }

        }
        catch (const json::parse_error& e) // json cannot be parsed
        {
            std::cerr << "JSON parse error: " << e.what() << "\n";
        }
    } 
    else // could not retrieve /lights from the server
    {
        std::cerr << "Failed to GET /lights\n";
    }
}

int main(int argc, char* argv[])
{
    // default values
    std::string host = "localhost";
    int port = 8080;
    int poll_rate = 2; // in seconds

    if (argc != 1 && argc != 4) // check if there are no arguments or four which are the two acceptable amounts
    {
        std::cout << "usage is ./josh_lighting_simulator or ./josh_lighting_simulator <host> <port> <poll_rate>";
        return 1;
    }

    // check for optional arguments
    if (argc > 1) host = argv[1];
    if (argc > 2) port = std::atoi(argv[2]);
    if (argc > 3) poll_rate = std::atoi(argv[3]);

    if (poll_rate <= 0) {
        std::cerr << "Invalid poll rate. Must be > 0 seconds.\n";
        return 1;
    }

    std::cout << "Initializing:\n" << "HOST: " << host << "\nPORT: " << port << "\nPOLL_RATE: " << poll_rate << std::endl; 

    // check that json lib is working
    std::cout << "Initializing JSON library\n";
    json state = json::object();
    std::cout << "JSON library initialized\n";

    // check that connection is made with the server
    std::cout << "Initializing server connection" << std::endl;
    httplib::Client client(host.c_str(), port);
    std::cout << "Server connection initialized" << std::endl;

    // Initial full light fetch
    auto res = client.Get("/lights"); // gather lights summary from the server
    if (res && res->status == 200) // validate response
    {
        try 
        {
            json summary_lights = json::parse(res->body);
            auto summary_map = to_map(summary_lights);
            std::string separator = "";
            std::cout << "[";
            for (const auto& pair : summary_map)
            {
                const auto& id = pair.first;
                std::cout << separator;
                json full_details = fetch_light_details(client, id);
                if (!full_details.is_null())
                {
                    state[id] = full_details;
                    json print_obj = full_details;
                    print_obj["id"] = id;
                    std::cout << print_obj.dump(4);
                }
                separator = ",\n";
            }
            std::cout << "]\n";
        } 
        catch (const json::parse_error& e) 
        {
            std::cerr << "Could not parse initial states: " << e.what() << "\n";
            return 1;
        }
    } 
    else 
    {
        std::cerr << "Error occured while connecting to the server";
        return 1;
    }

    while (true)
    {
        poll(client, state);
        std::this_thread::sleep_for(std::chrono::seconds(poll_rate));
    }

    return 0;
}