#include "httplib.h"
#include "json.hpp"
#include <thread>
#include <iostream>
#include <chrono>
#include <cstdlib>
#include <cstdio>
#include <sstream>

using json = nlohmann::json;
using namespace std::chrono_literals;


// Function to remove all lights - Usualy useful at the start or end of a program
void remove_all_lights(httplib::Client& client)
{

    auto res = client.Get("/lights");
    if (!res || res->status != 200) 
    {
        std::cerr << "Failed to fetch lights\n";
        return;
    }

    json lights;
    try
    {
        lights = json::parse(res->body);
    }
    catch (const json::parse_error& e)
    {
        std::cerr << "Failed to parse response: " << e.what() << "\n";
        return;
    }

    for (const auto& light : lights) 
    {

        std::string id = light["id"];
        std::string endpoint = "/lights/" + id;

        auto del_res = client.Delete(endpoint.c_str());
        if (del_res && del_res->status == 204)
        {
            std::cout << "Deleted light " << id << "\n";
        }
        else
        {
            std::cerr << "Failed to delete light " << id 
                      << " (status: " << (del_res ? std::to_string(del_res->status) : "no response") << ")\n";
        }
    }
}

// get a light json with random properties
json get_light_with_random_properties()
{
    std::vector<std::string> rooms = {"Living Room", "Patio", "Kitchen", "Dining Room", "Office", "Balcony"};
    
    json new_light;
    new_light["name"] = "Light_" + std::to_string(rand() % 1000);
    new_light["room"] = rooms[rand()%rooms.size()];
    new_light["on"] = (rand() % 2 == 0);
    new_light["brightness"] = rand() % 256;
    return new_light;
}

// get a light json with specificed properties
json get_light_with_specific_properties(const std::string& name, const std::string& room, const bool& on, const int8_t& brightness)
{
    json new_light;
    new_light["name"] = name;
    new_light["room"] = room;
    new_light["on"] = on;
    new_light["brightness"] = brightness;
    return new_light;
}

std::string insert_light(httplib::Client& client, const json& light) // insert a light using a light json (can be easily retrieved using the get_light_* functions)
{
    auto res = client.Post("/lights", light.dump(), "application/json");
    if (res && res->status == 201)
    {
        std::cout << "Successfully created light:\n" << res->body << "\n";
        return json::parse(res->body)["id"];
    }
    else
    {
        std::cerr << "Failed to create light (status: " 
                  << (res ? std::to_string(res->status) : "no response") << ")\n";
        return "";
    }
}

void delete_light(httplib::Client& client, const std::string& id) // Delete a light using the id provided and the client provided
{
    std::string endpoint = "/lights/" + id;

    auto del_res = client.Delete(endpoint.c_str());
    if (del_res && del_res->status == 204)
    {
        std::cout << "Deleted light " << id << "\n";
    }
    else
    {
        std::cerr << "Failed to delete light " << id 
                    << " (status: " << (del_res ? std::to_string(del_res->status) : "no response") << ")\n";
    }
}

void update_random_light(httplib::Client& client) // Updates a random light from the list of lights
{
    auto res = client.Get("/lights");
    if (!res || res->status != 200) 
    {
        std::cerr << "Failed to fetch lights\n";
        return;
    }

    json lights;
    try
    {
        lights = json::parse(res->body);
    }
    catch (const json::parse_error& e)
    {
        std::cerr << "Failed to parse response: " << e.what() << "\n";
        return;
    }

    auto light_index = rand() % lights.size();
    std::string light_id = lights[light_index]["id"];

    std::vector<std::string> rooms = {"Living Room", "Patio", "Kitchen", "Dining Room", "Office", "Balcony"};
    json update;
    // randomly pick attributes to change and print them in a similar way to the main program for easier referencing
    if (rand() % 2) 
    {
        const auto& old_name = lights[light_index]["name"];
        update["name"] = "Light_" + std::to_string(rand() % 1000);
        if (update["name"] != old_name) std::cout << "{\n\t" << "id: " << "\"" << light_id << "\",\n\t" << "name: " << update["name"] << "\n}\n";
    }
    if (rand() % 2)
    {
        const auto& old_room = lights[light_index]["room"];
        update["room"] = rooms[rand()%rooms.size()]; 
        if (update["room"] != old_room) std::cout << "{\n\t" << "id: " << "\"" << light_id << "\",\n\t" << "room: " << update["room"] << "\n}\n";
    }
    if (rand() % 2)
    { 
        const auto& old_on = lights[light_index]["on"];
        update["on"] = (rand() % 2 == 0); 
        if (update["on"] != old_on) std::cout << "{\n\t" << "id: " << "\"" << light_id << "\",\n\t" << "on: " << "\"" << update["on"] << "\"\n}\n";
    }
    if (rand() % 2)
    { 
        const auto& old_brightness = lights[light_index]["brightness"];
        update["brightness"] = rand() % 256; 
        if (update["brightness"] != old_brightness) std::cout << "{\n\t" << "id: " << "\"" << light_id << "\",\n\t" << "brightness: " << "\"" << update["brightness"] << "\"\n}\n";
    }

    auto put_res = client.Put(("/lights/" + light_id).c_str(), update.dump(), "application/json");


}

int main()
{
    std::srand(std::time(nullptr));
    httplib::Client client("localhost", 8080); 

    // All code below can be edited to test different functions and behaviors 
    remove_all_lights(client); // after launching fresh sim remove all lights for clean slate
    std::this_thread::sleep_for(std::chrono::seconds(2)); // Typically sleep for 2 seconds after operations otherwise the program may miss some changes if they're all executed before the next poll

    for (int i = 0; i < 10; i ++) insert_light(client, get_light_with_random_properties());
    
    std::this_thread::sleep_for(std::chrono::seconds(2));
    update_random_light(client);
    std::this_thread::sleep_for(std::chrono::seconds(2));
    update_random_light(client);
    update_random_light(client);
    update_random_light(client);
    update_random_light(client);
    std::this_thread::sleep_for(std::chrono::seconds(2));

    return 1;
}