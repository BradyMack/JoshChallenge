=====OVERVIEW=====
The following project is a simulated light system monitor that presents all lights in the system at launch and detects changes and prints them accordingly any time the system:
1. Adds a light
2. Removes a light
3 Has a change to the attribute of a light (name, room, brightness, on/off state)
Project details and light_simulator api defined respectively here
https://github.com/jstarllc/JoshCodingChallenge?tab=readme-ov-file
https://github.com/jstarllc/JoshCodingChallenge/releases/tag/v1.0

=====DEPENDENCIES=====
The project in main.cpp is built using c++14 as recommended by the project detail
The external libraries used are nlohmann json and cpp-httplib, these are located in the /external folder and will not require any installation
The program requires CMAKE to build

=====BUILDING=====
To build the program, create or navigate to the build folder and run:
cmake ..
make
This will build the binary "josh_lighting_simulator" and the binary "tests" (More usage details for tests later on)
*** There are precompiled binaries built using AArch64/ARM64 architecture compiled on an M3 macbook

=====RUNNING THE PROGRAM=====
The program can be run from the build directory with
./josh_lighting_simulator <host> <port> <poll_rate>
where <poll_rate> is the frequency the program tries to detect changes in seconds
If no arguments are provided it will default to localhost:8080 with a poll rate = 2
To exit use ctrl+c

=====APPROACH=====
The program can be broken down into a few sections
1. In main() the program is initialized, the command line args are parsed, the libraries are ensured to be working properly, the connection to the server is made, the initial state of the lights is printed, and lastly the polling loop is started
2. Because we are are continuously checking for changes to the array of lights a polling loop is called from main() called poll(...). This is called periodically (default every 2s) and the current state of the lights is compared against what was present in the previous call to the /lights endpoint.
    2a. Because we are checking for all changes and not just a change to the summary this delves into each individual light's detail using GET /lights/<id> in fetch_light_details(...)
3. Print any appropriate updates

=====CONSIDERATIONS/EDGE CASES=====
While completing this exercise, numerous thoughts of things they may potentially cause issues crossed my mind.
1. What if libraries are not loaded properly
    The program will abort if libraries don't successfully load
2. What if the server doesn't start properly
    The program will inform the user the server was not initialized successfully and exit
3. What if a user provides invalid or no command line arguments
    The program will inform the user of usage and exist
4. What about any miscellaneous errors or issues with data handling or connecting to the server
    Error handling is provided throughout the program in the form of try...catch blocks
    The program WILL exit if the server cannot be connected to initially but WILL NOT exit if it loses connection it will just print an error

=====TESTING=====
In tests.cpp there are numerous functions that I made in order to test different things, without adding too many libraries for testing I was able to quickly make random and repeatable tests and compare the output with what the tests changed
To test the program there are functions to add, delete, and modify lights. In order to test, the simulator and josh_lighting_simulator C++ binary must be active to see results when ./tests is run. Changes to the server will still be made if the monitoring program that was the assignment is not running they just will only be printed by the testing program.
I used ./josh_lighting_simulator > sim_output.txt and ./tests > test_output.txt to check the validity of the actions on different scales - a future improvement could be to make a script to automatically compare these outputs or use a testing library to assert values in another way

=====DESIGN DECISIONS=====
Why the general design?
The general design allows for us to continuosly poll the server and find both broad summary level changes as well as minor details such as brightness
Why maps?
Maps provide an storage efficient and quick way to find differences between jsons in between calls - it is easy to iterate through the data we receive from the /lights endpoint and compare it to what we previously had using id lookups
Why polling?
Polling provides a simple repeatable process to check what is happening on the server (with different intervals for polling possible)
Why pretty printing?
Although not the most efficient way to present data it is easy to read and makes debugging and understanding what's happening easier

=====ISSUES AND IMPROVEMENTS=====
This is of course a theoretical exercise and actual hardware behavior could affect the behavior of this program
Multi-threading could be an interesting venture, but given the time sensitive and some what chronological necessity I left it off
Depending on different systems and need for quicker updating it may be worthwhile to fine tune the polling rate
Full scale integration testing and unit testing would be necessary
Upon testing very large selections, it also became clear some sort of sending using packets or pagination would also be beneficial to not lose data with large sample